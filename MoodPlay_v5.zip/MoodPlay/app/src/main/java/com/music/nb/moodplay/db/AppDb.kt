package com.music.nb.moodplay.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [User::class], version = 1)
abstract class AppDb: RoomDatabase() {
    abstract fun userDao(): UserDao

    companion object {
        @Volatile
        private var INSTANTCE: AppDb? = null

        fun getDatabase(context: Context): AppDb {
            val temp = INSTANTCE
            if (temp != null) {
                return temp
            }
            synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDb::class.java,
                    "user-db"
                ).build()
                INSTANTCE = instance
                return instance
            }
        }
    }
}