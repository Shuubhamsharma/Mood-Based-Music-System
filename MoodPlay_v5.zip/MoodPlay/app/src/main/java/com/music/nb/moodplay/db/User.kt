package com.music.nb.moodplay.db

import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity
data class User (
    @ColumnInfo(name = "user_name") val Username: String,
    @ColumnInfo(name = "email_id") val email: String,
    @ColumnInfo(name = "pass") val pass: String,
    @PrimaryKey(autoGenerate = true) val uid: Int? = null
    )