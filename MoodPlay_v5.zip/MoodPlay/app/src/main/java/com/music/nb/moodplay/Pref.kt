package com.music.nb.moodplay

import android.content.Context
import android.content.Context.MODE_PRIVATE
import android.content.SharedPreferences

class Pref {

    companion object{

        const val PREFS:String = "prefs"
        const val KEY_LANGUAGE = "language"
        const val KEY_MOOD = "mood"
        const val KEY_SONG_TYPE = "song_type"
        const val KEY_ISLOGGED_IN = "is_logged_in"

        fun putStrings(context: Context, key: String, value: String) {
            val sp = context.getSharedPreferences(PREFS, MODE_PRIVATE)
            with (sp.edit()) {
                putString(key, value)
                apply()
            }
        }

        fun getString(context: Context, key: String): String {
            val sp = context.getSharedPreferences(PREFS, MODE_PRIVATE)
            return sp.getString(key, "").toString()
        }

        fun putBoolean(context: Context, key: String, value: Boolean) {
            val sp = context.getSharedPreferences(PREFS, MODE_PRIVATE)
            with (sp.edit()) {
                putBoolean(key, value)
                apply()
            }
        }

        fun getBoolean(context: Context, key: String): Boolean {
            val sp = context.getSharedPreferences(PREFS, MODE_PRIVATE)
            return sp.getBoolean(key, false)
        }

    }



}