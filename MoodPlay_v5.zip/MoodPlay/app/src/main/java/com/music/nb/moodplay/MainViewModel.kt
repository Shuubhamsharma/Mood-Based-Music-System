package com.music.nb.moodplay

import android.app.Application
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.music.nb.moodplay.db.AppDb
import com.music.nb.moodplay.db.User
import kotlinx.coroutines.launch

class MainViewModel(application: Application): AndroidViewModel(application) {

    val appDb: AppDb = AppDb.getDatabase(application)

//    private lateinit var currentUser:User
    var userError: MutableLiveData<String> = MutableLiveData()
    var passError: MutableLiveData<String> = MutableLiveData()
    var mailError: MutableLiveData<String> = MutableLiveData()
    var isValidUserLogin: MutableLiveData<Boolean>  = MutableLiveData()
    var isValidUserSignUp: MutableLiveData<Boolean> = MutableLiveData()

    fun getUserByName(username: String) {

//        viewModelScope.launch {
//            currentUser = appDb.userDao().getByUsername(username)
//        }

    }

    fun checkAndSetUser(username: String, pass: String){
        viewModelScope.launch {
            val currentUser = appDb.userDao().getByUsername(username)

            if (currentUser == null) {
                userError.value = "User doesn't exist."
            } else {
                if (pass.contentEquals(currentUser.pass)) {
                    isValidUserLogin.value = true
                } else {
                    passError.value = "Wrong password."
                }
            }

        }
    }

    fun checkAndSignupUser(username: String, pass: String, mail:String){

        if (username.isEmpty() || pass.isEmpty() || mail.isEmpty()) {
            Toast.makeText(getApplication(), "Values can't be empty", Toast.LENGTH_SHORT).show()
            return
        }

        viewModelScope.launch {
            val currentUser = appDb.userDao().getByUsername(username)

            if (currentUser == null) {
                appDb.userDao().insertAll(User(username, mail, pass))
                isValidUserSignUp.value = true
            } else {
                userError.value = "User already exist"
            }

        }
    }

}