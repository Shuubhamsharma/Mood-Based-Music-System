package com.music.nb.moodplay


import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RelativeLayout
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

import com.example.aks.echo.Songs


/**
 * A simple [Fragment] subclass.
 */
class SongsListAdapter(_songDetails: ArrayList<Songs>, _context: Context)
    : RecyclerView.Adapter<SongsListAdapter.MyViewHolder>() {

    var songDetails: ArrayList<Songs>? = null
    var mContext: Context? = null
    lateinit var onclickHandler: OnclickHandler

    init {
        this.songDetails = _songDetails
        this.mContext = _context
    }

    fun updateData(songDetails: ArrayList<Songs>?) {
        this.songDetails = songDetails
        notifyDataSetChanged()
    }

    fun addClickHandler(onclickHandler: OnclickHandler) {
        this.onclickHandler = onclickHandler
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        val songObject = songDetails?.get(position)
        holder.trackTitle?.text = songObject?.songTitle
        holder.trackArtist?.text = songObject?.artist
        holder.contentHolder?.setOnClickListener{
            onclickHandler.onSongClick(songObject!!, position, songDetails)
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        val itemView = LayoutInflater.from(parent?.context)
                .inflate(R.layout.row_custom_mainscreen_adapter, parent, false)
        return MyViewHolder(itemView)
    }

    override fun getItemCount(): Int {
        if (songDetails == null)
            return 0

        return (songDetails as ArrayList<Songs>).size
    }

    class MyViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        var trackTitle: TextView? = null
        var trackArtist: TextView? = null
        var contentHolder: RelativeLayout? = null

        init {
            trackTitle = view.findViewById(R.id.trackTitle)
            trackArtist = view.findViewById(R.id.trackArtist)
            contentHolder = view.findViewById<RelativeLayout>(R.id.contentRow)
        }
    }

    interface OnclickHandler {
        fun onSongClick(song: Songs, position: Int, songDetails: ArrayList<Songs>?)
    }

//    fun isFragmentExists(tag: String): Boolean {
//        //var frag : Fragment = Fragment().getFragmentManager().findFragmentByTag(tag)
//        try {
//            if (Fragment().getFragmentManager().findFragmentByTag(tag) != null) {
//                println("--------------------------------------------In try inside if")
//                Log.i("MY MESSAGE", "NullPointerException did not occur")
//                return true
//            }
//            println("--------------------------------------------In try outside if")
//            return false
//        } catch (e: NullPointerException) {
//            println("-------------------------------------------------------------In catch")
//            Log.i("MY MESSAGE", "NullPointerException occured")
//            return false
//        }
//    }

}// Required empty public constructor
