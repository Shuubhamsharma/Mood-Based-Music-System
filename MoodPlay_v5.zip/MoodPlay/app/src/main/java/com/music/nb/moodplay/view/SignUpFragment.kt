package com.music.nb.moodplay.view

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.music.nb.moodplay.MainViewModel
import com.music.nb.moodplay.Pref
import com.music.nb.moodplay.R

class SignUpFragment : Fragment(){

//    companion object {
//        fun newInstance(isDone:Boolean) = SignUpFragment()
//            .apply {
//            arguments = Bundle().apply {
//                putBoolean("is_done", isDone)
//            }
//        }
//    }

    lateinit var navController: NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
//        arguments?.apply {
//            isDoneFragment = getBoolean("is_done")
//        }

        navController = NavHostFragment.findNavController(this)
    }

    private lateinit var viewModel: MainViewModel

    private lateinit var tetName: TextInputEditText
    private lateinit var tilName: TextInputLayout
    private lateinit var tetPass: TextInputEditText
    private lateinit var tilPass: TextInputLayout
    private lateinit var tetMail: TextInputEditText
    private lateinit var tilMail: TextInputLayout
    private lateinit var btnSignup: Button



    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fm_signupp, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        tetName = view.findViewById(R.id.tet_name)
        tilName = view.findViewById(R.id.til_name)
        tetPass = view.findViewById(R.id.tet_pass)
        tilPass = view.findViewById(R.id.til_pass)
        tetMail = view.findViewById(R.id.tet_mail)
        tilMail = view.findViewById(R.id.til_mail)
        btnSignup = view.findViewById(R.id.btn_signup)


    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        viewModel.userError.observe(viewLifecycleOwner, Observer {
            tilName.error = it
        })

        viewModel.passError.observe(viewLifecycleOwner, Observer {
            tilPass.error = it
        })

        viewModel.passError.observe(viewLifecycleOwner, Observer {
            tilPass.error = it
        })

        viewModel.isValidUserSignUp.observe(viewLifecycleOwner, Observer {
            if (it) {
                Toast.makeText(requireContext(), "User created successfully", Toast.LENGTH_SHORT).show()
//                Pref.putBoolean(requireContext(), Pref.KEY_ISLOGGED_IN, true)
//                navController.navigate(R.id.action_signUpFragment_to_songsListFragment, bundleOf(Pair("isFreshLogin", true)))
                navController.popBackStack()
            }
        })

        btnSignup.setOnClickListener {

            val username = this.tetName.text.toString()
            val pass = this.tetPass.text.toString()
            val mail = this.tetMail.text.toString()

            viewModel.checkAndSignupUser(username, pass, mail)

        }

    }
}