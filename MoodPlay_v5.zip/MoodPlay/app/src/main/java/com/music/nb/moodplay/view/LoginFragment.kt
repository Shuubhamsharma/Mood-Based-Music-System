package com.music.nb.moodplay.view

import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.core.os.bundleOf
import androidx.lifecycle.Observer
import androidx.lifecycle.ViewModelProvider
import androidx.navigation.NavController
import androidx.navigation.fragment.NavHostFragment
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.music.nb.moodplay.MainViewModel
import com.music.nb.moodplay.Pref
import com.music.nb.moodplay.R

class LoginFragment : Fragment(){

    lateinit var navController:NavController

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        navController = NavHostFragment.findNavController(this)
    }

    private lateinit var viewModel: MainViewModel

    private lateinit var tetName: TextInputEditText
    private lateinit var tilName: TextInputLayout
    private lateinit var tetPass: TextInputEditText
    private lateinit var tilPass: TextInputLayout
    private lateinit var btnLogin: Button
    private lateinit var tvSignup: TextView

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        return inflater.inflate(R.layout.fm_loginn, container, false)
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        tetName = view.findViewById(R.id.tet_name)
        tilName = view.findViewById(R.id.til_name)
        tetPass = view.findViewById(R.id.tet_pass)
        tilPass = view.findViewById(R.id.til_pass)
        btnLogin = view.findViewById(R.id.btn_login)
        tvSignup = view.findViewById(R.id.tv_signup)

        tilPass.setEndIconActivated(false)


    }

    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        viewModel = ViewModelProvider(this).get(MainViewModel::class.java)

        viewModel.userError.observe(viewLifecycleOwner, Observer {
            tilName.error = it
        })

        viewModel.passError.observe(viewLifecycleOwner, Observer {
            tilPass.error = it
        })

        viewModel.isValidUserLogin.observe(viewLifecycleOwner, Observer {
            if (it) {
                Toast.makeText(requireContext(), "Logged in successfully", Toast.LENGTH_SHORT).show()
                Pref.putBoolean(requireContext(), Pref.KEY_ISLOGGED_IN, true)
//                navController.navigate(R.id.action_loginFragment_to_songsListFragment)

                navController.navigate(R.id.action_loginFragment_to_songsListFragment, bundleOf(Pair("isFreshLogin", true)))

            }
        })

        btnLogin.setOnClickListener {

            var username = LoginFragment@this.tetName.text.toString()
            var pass = LoginFragment@this.tetPass.text.toString()

            viewModel.checkAndSetUser(username, pass)

        }

        tvSignup.setOnClickListener {
            navController.navigate(R.id.signUpFragment)
        }

    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        menu?.clear()
        inflater?.inflate(R.menu.song_playing_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            R.id.action_redirect -> {
                activity?.onBackPressed()
                return false
            }
        }
        return false
    }

}