package com.music.nb.moodplay.view


import android.app.Activity
import android.content.Context
import android.content.DialogInterface
import android.media.MediaPlayer
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.*
import android.widget.*
import androidx.appcompat.app.AlertDialog
import com.example.aks.echo.Songs
import androidx.fragment.app.Fragment
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.music.nb.moodplay.Pref
import com.music.nb.moodplay.R
import com.music.nb.moodplay.SongsListAdapter
import java.io.File
import kotlin.collections.ArrayList


/**
 * A simple [Fragment] subclass.
 */
class SongsListFragment : Fragment() {

    var getSongsList: ArrayList<Songs>? = null
    var nowPlayingBottomBar: RelativeLayout? = null
    var playPauseButton: ImageButton? = null
    var songTitle: TextView? = null
    var visibleLayout: RelativeLayout? = null
    var noSongs: RelativeLayout? = null
    var recyclerView: RecyclerView? = null
    var trackPosition: Int = 0

    var myActitvity: Activity? = null

    var _mainScreenAdapter: SongsListAdapter? = null

    var onceDone: Boolean = false;

    object Statified {
        var mediaPlayer: MediaPlayer? = null
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?,
                              savedInstanceState: Bundle?): View? {
        // Inflate the layout for this fragment
        val view = inflater!!.inflate(R.layout.fragment_main_screen, container, false)

        setHasOptionsMenu(true)

        activity!!.title = "Welcome to Mood Play"

        visibleLayout = view?.findViewById(R.id.visibleLayout)
        noSongs = view?.findViewById(R.id.noSongs)
        nowPlayingBottomBar = view?.findViewById(R.id.hiddenBarMainScreen)
        songTitle = view?.findViewById(R.id.songTitleMainScreen)
        playPauseButton = view?.findViewById(R.id.playPauseButton)
        recyclerView = view?.findViewById(R.id.contentMain)


        return view
    }


    override fun onActivityCreated(savedInstanceState: Bundle?) {
        super.onActivityCreated(savedInstanceState)

        val navController = findNavController()

        val isLoggedIn = Pref.getBoolean(requireContext(), Pref.KEY_ISLOGGED_IN)

        if (!isLoggedIn) {
            val navGraph = navController.navInflater.inflate(R.navigation.nav_graph)
            navGraph.startDestination = R.id.loginFragment
            navController.graph = navGraph
            return
        }


//        getSongsList = getSongsFromPhone("${Pref.getString(requireContext(), Pref.KEY_LANGUAGE)}/${Pref.getString(requireContext(), Pref.KEY_MOOD)}/${Pref.getString(requireContext(), Pref.KEY_SONG_TYPE)}")
        getSongsList = getSongsFromPhone(Pref.getString(requireContext(), Pref.KEY_SONG_TYPE))

//        val prefs = activity!!.getSharedPreferences("action_sort", Context.MODE_PRIVATE)
//        val action_sort_ascending = prefs.getString("action_sort_ascending", "true")
//        val action_sort_recent = prefs.getString("action_sort_recent", "false")

        if (getSongsList == null) {
            visibleLayout?.visibility = View.INVISIBLE
            noSongs?.visibility = View.VISIBLE
        } else {
            _mainScreenAdapter = SongsListAdapter(getSongsList as ArrayList<Songs>, myActitvity as Context)


//            recyclerView?.itemAnimator = DefaultItemAnimator()
            recyclerView?.adapter = _mainScreenAdapter

            _mainScreenAdapter!!.onclickHandler = object:SongsListAdapter.OnclickHandler {
                override fun onSongClick(
                    songObject: Songs,
                    position: Int,
                    songDetails: ArrayList<Songs>?
                ) {

                        val songPlayingFragment = SongPlayingFragment()
                        var args = Bundle()
                        args.putString("songArtist", songObject?.artist)
                        args.putString("path", songObject?.songData)
                        args.putString("songTitle", songObject?.songTitle)
                        args.putInt("SongId", songObject?.songId?.toInt() as Int)
                        args.putInt("songPosition", position)
                        args.putParcelableArray("songData", songDetails?.toTypedArray())

                        songPlayingFragment.arguments = args       // linking songPlayingFragment to Bundle obj

//            println("----------------------------------------------------going to call isFragmentExists() method")
//            if (isFragmentExists("SongPlayingFragment")) {
//                (mContext as FragmentActivity).supportFragmentManager
//                        .beginTransaction()
//                        .remove(Fragment().getFragmentManager().findFragmentByTag("SongPlayingFragment"))
//                        .replace(R.id.details_fragment, songPlayingFragment, "SongPlayingFragment")
//                        .commit()
//            } else {
//                (mContext as FragmentActivity).supportFragmentManager
//                        .beginTransaction()
//                        .replace(R.id.details_fragment, songPlayingFragment, "SongPlayingFragment")
//                        .commit()
//            }

                        if(SongPlayingFragment.Statified.mediaPlayer != null && SongPlayingFragment.Statified.mediaPlayer?.isPlaying as Boolean){
                            SongPlayingFragment.Statified.mediaPlayer?.pause()
                            SongPlayingFragment.Statified.mediaPlayer?.release()
                        }

//                        (mContext as FragmentActivity).supportFragmentManager
//                            .beginTransaction()
//                            .replace(R.id.details_fragment, songPlayingFragment, "SongPlayingFragment")
//                            .addToBackStack("SongPlayingFragment")
//                            .commit()

                    findNavController().navigate(R.id.songPlayingFragment, args)




                }

            }

            val mLayoutManager = LinearLayoutManager(myActitvity)
            recyclerView?.layoutManager = mLayoutManager
            _mainScreenAdapter!!.updateData(getSongsList)
        }

//        updateList()

        if (!onceDone) {

//            if (arguments?.getBoolean("isFreshLogin") == true || Pref.getString(requireContext(), Pref.KEY_LANGUAGE).isEmpty()) {
//                changeLanguageMood()
//            } else {
//                changeMood()
//            }

            changeSongsMood()

        }



//        if (getSongsList != null) {
//            if (action_sort_ascending!!.equals("true", true)) {
//                Collections.sort(getSongsList, Songs.Statified.nameComparator)
//                _mainScreenAdapter?.notifyDataSetChanged()
//            } else if (action_sort_recent!!.equals("true", true)) {
//                Collections.sort(getSongsList, Songs.Statified.dateComparator)
//                _mainScreenAdapter?.notifyDataSetChanged()
//            }
//        }

//        bottomBarSetup()

        onceDone = true
    }


    override fun onAttach(context: Context) {
        super.onAttach(context)
        myActitvity = context as Activity
    }

    override fun onAttach(activity: Activity) {
        super.onAttach(activity)
        myActitvity = activity
    }

    override fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        menu?.clear()
        inflater?.inflate(R.menu.songs_menu, menu)
        super.onCreateOptionsMenu(menu, inflater)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item?.itemId) {
            R.id.action_logout -> {
                logout()
                return false
            }
            R.id.action_change_mood -> {
                changeSongsMood()
                return false
            }
        }
        return false
    }

    private fun changeSongsMood() {

        val dir = File("${Environment.getExternalStorageDirectory().absolutePath}/moodplay")
//        val dir = File("${requireContext().getExternalFilesDir(null)}/moodplay")
//        dir.setReadable(true, false)
//        dir.mkdir()
        val langs = dir.listFiles()
        val dirNames = langs.map { it.name }

        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Choose language")

        builder.setItems(dirNames.toTypedArray()) { _: DialogInterface, pos: Int ->

            Pref.putStrings(requireContext(), Pref.KEY_SONG_TYPE, langs[pos].absolutePath)
            val moods = langs[pos].listFiles()
            changeMood(moods)

        }
        val dialog = builder.create()
        dialog.show()




    }

//    private fun changeLanguageMood() {
//
////        val dir = activity?.getExternalFilesDir("${Environment.DIRECTORY_MUSIC}/moodplay")
//        val dir = File("${Environment.getExternalStorageDirectory().absolutePath}/moodplay")
//
//        val langs = dir.listFiles()
//
//        val dirNames = langs.map { it.name }
//
//        val builder = AlertDialog.Builder(requireContext())
//        builder.setTitle("Choose language")
//
//        builder.setItems(dirNames.toTypedArray(), DialogInterface.OnClickListener{ dialogInterface: DialogInterface, pos: Int ->
//
//            Pref.putStrings(requireContext(), Pref.KEY_LANGUAGE, dirNames[pos])
//            val moods = langs[pos].listFiles()
//            val moodNames = moods.map { it.name }
//
//            changeMood(moodNames)
//
//        })
//
////// add OK and Cancel buttons
////        builder.setPositiveButton("OK") { dialog, which ->
////            // user clicked OK
////        }
////        builder.setNegativeButton("Cancel", null)
////
////// create and show the alert dialog
//        val dialog = builder.create()
//        dialog.show()
//
//
//
//
//    }

    private fun changeMood(moods: Array<File>) {

        val moodnames = moods.map { it.name }

        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Choose Mood")
        builder.setItems(moodnames.toTypedArray()) { _: DialogInterface, pos: Int ->

            Pref.putStrings(requireContext(), Pref.KEY_SONG_TYPE, moods[pos].absolutePath)

            val songTypes = moods[pos].listFiles()
            changeSongType(songTypes)

        }

        val dialog = builder.create()
        dialog.show()
    }

    private fun changeSongType(songTypes: Array<File>) {

        val names = songTypes.map { it.name }

        val builder = AlertDialog.Builder(requireContext())
        builder.setTitle("Choose Type")
        builder.setItems(names.toTypedArray()) { _: DialogInterface, pos: Int ->
            Pref.putStrings(requireContext(), Pref.KEY_SONG_TYPE, songTypes[pos].absolutePath)
            updateList()
        }

        val dialog = builder.create()
        dialog.show()
    }

    private fun updateList() {
//        val songs = getSongsFromPhone("${Pref.getString(requireContext(), Pref.KEY_LANGUAGE)}/${Pref.getString(requireContext(), Pref.KEY_MOOD)}")
        val songs = getSongsFromPhone(Pref.getString(requireContext(), Pref.KEY_SONG_TYPE))
        _mainScreenAdapter?.updateData(songs)
    }

    private fun logout() {

        AlertDialog.Builder(requireContext())
            .setMessage("Are you sure, you want to logout?")
            .setPositiveButton("Yes") { dialogInterface: DialogInterface, i: Int ->
                val navController = findNavController()
                val navGraph = navController.navInflater.inflate(R.navigation.nav_graph)
                navGraph.startDestination = R.id.loginFragment
                navController.graph = navGraph

                Pref.putBoolean(requireContext(), Pref.KEY_ISLOGGED_IN, false)
            }
            .setNegativeButton("No") { dialogInterface: DialogInterface, i: Int ->
                dialogInterface.dismiss()
            }.create().show()
    }

//    override fun onOptionsItemSelected(item: MenuItem): Boolean {
//        val switcher = item?.itemId
//
//        if (switcher == R.id.action_sort_ascending) {
//
//            val editor = myActitvity?.getSharedPreferences("action_sort", Context.MODE_PRIVATE)?.edit()
//            editor?.putString("action_sort_ascending", "true")
//            editor?.putString("action_sort_recent", "false")
//            editor?.apply()
//
//            if (getSongsList != null) {
//                Collections.sort(getSongsList, Songs.Statified.nameComparator)
//                _mainScreenAdapter?.notifyDataSetChanged()
//            }
//
//            return false
//        } else if (switcher == R.id.action_sort_recent) {
//            val editor = myActitvity?.getSharedPreferences("action_sort", Context.MODE_PRIVATE)?.edit()
//            editor?.putString("action_sort_ascending", "false")
//            editor?.putString("action_sort_recent", "true")
//            editor?.apply()
//            if (getSongsList != null) {
//                Collections.sort(getSongsList, Songs.Statified.dateComparator)
//                _mainScreenAdapter?.notifyDataSetChanged()
//            }
//            return false
//        }
//        return super.onOptionsItemSelected(item)
//    }

    fun getSongsFromPhone(filter: String): ArrayList<Songs> {
        var arrayList = ArrayList<Songs>()
        var contentResolver = myActitvity?.contentResolver
        var songUri = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        var songCursor = contentResolver?.query(songUri, null, MediaStore.Audio.Media.DATA + " like ? ", arrayOf("%$filter%"), null)

        if (songCursor != null) {
            val songId = songCursor.getColumnIndex(MediaStore.Audio.Media._ID)
            val songTitle = songCursor.getColumnIndex(MediaStore.Audio.Media.TITLE)
            val songArtist = songCursor.getColumnIndex(MediaStore.Audio.Media.ARTIST)
            val songData = songCursor.getColumnIndex(MediaStore.Audio.Media.DATA)
            val dateIndex = songCursor.getColumnIndex(MediaStore.Audio.Media.DATE_ADDED)
            while (songCursor.moveToNext()) {
                var currentId = songCursor.getLong(songId)
                var currentTitle = songCursor.getString(songTitle)
                var currentArtist = songCursor.getString(songArtist)
                var currentData = songCursor.getString(songData)
                var currentDate = songCursor.getLong(dateIndex)
                arrayList.add(Songs(currentId, currentTitle, currentArtist, currentData, currentDate))
            }
        }
        return arrayList
    }


//    fun bottomBarSetup() {
//        try {
//            bottomBarClickHandler()
//            songTitle?.setText(SongPlayingFragment.Statified.currentSongHelper?.songTitle)
//            SongPlayingFragment.Statified.mediaPlayer?.setOnCompletionListener({
//                songTitle?.setText(SongPlayingFragment.Statified.currentSongHelper?.songTitle)
//                SongPlayingFragment.Staticated.onSongComplete()
//            })
//
//            if (SongPlayingFragment.Statified.mediaPlayer?.isPlaying as Boolean) {
//                nowPlayingBottomBar?.visibility = View.VISIBLE
//            } else {
//                nowPlayingBottomBar?.visibility = View.INVISIBLE
//            }
//        } catch (e: Exception) {
//            e.printStackTrace()
//        }
//    }
//
//    fun bottomBarClickHandler() {
//        nowPlayingBottomBar?.setOnClickListener({
//            val songPlayingFragment = SongPlayingFragment()
//            SongsListFragment.Statified.mediaPlayer = SongPlayingFragment.Statified.mediaPlayer
//            var args = Bundle()
//            args.putString("songArtist", SongPlayingFragment.Statified.currentSongHelper?.songArtist)
//            args.putString("path", SongPlayingFragment.Statified.currentSongHelper?.songPath)
//            args.putString("songTitle", SongPlayingFragment.Statified.currentSongHelper?.songTitle)
//            args.putInt("SongId", SongPlayingFragment.Statified.currentSongHelper?.songId?.toInt() as Int)
//            args.putInt("songPosition", SongPlayingFragment.Statified.currentSongHelper?.currentPosition?.toInt() as Int)
//            args.putParcelableArrayList("songData", SongPlayingFragment.Statified._fetchSongs)
//            args.putString("MainScreenBottomBar", "success")
//            songPlayingFragment.arguments = args       // linking songPlayingFragment to Bundle obj
//
////           var frg: Fragment? = fragmentManager.findFragmentByTag("SongPlayingFragment")
////            if(frg != null){
////                println("===============================An existing Fragment Found===================================")
////                frg.onDestroy()
////            }else{
////                println("===============================Fragment not found=================================")
////            }
//
//            fragmentManager.beginTransaction()
//                    .replace(R.id.details_fragment, songPlayingFragment, "SongPlayingFragment")
//                    .addToBackStack("SongPlayingFragment")
//                    .commit()
//
//        })
//
//        playPauseButton?.setOnClickListener({
//            if (SongPlayingFragment.Statified.mediaPlayer?.isPlaying as Boolean) {
//                SongPlayingFragment.Statified.mediaPlayer?.pause()
//                trackPosition = SongPlayingFragment.Statified.mediaPlayer?.currentPosition as Int
//                playPauseButton?.setBackgroundResource(R.drawable.play_icon)
//            } else {
//                SongPlayingFragment.Statified.mediaPlayer?.seekTo(trackPosition)
//                SongPlayingFragment.Statified.mediaPlayer?.start()
//                playPauseButton?.setBackgroundResource(R.drawable.pause_icon)
//            }
//        })
//    }


}// Required empty public constructor
